
# SOLA Website

## SIMPLE PHONE INSTRUCTIONS

1. Upload this ZIP to GitHub
2. Open Vercel
3. Import GitHub repo
4. Click DEPLOY

Done.

## IMPORTANT

Replace:
public/sola-logo.png

with your dolphin image if needed.

## INSTALL COMMANDS (if Vercel asks)

npm install

## BUILD COMMAND

npm run build
