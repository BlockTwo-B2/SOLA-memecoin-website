
export const metadata = {
  title: 'SOLA the Dolphin',
  description: 'SOLA memecoin on Solana',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
