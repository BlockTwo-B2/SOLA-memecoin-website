
'use client'

import { motion } from 'framer-motion'
import {
  Waves,
  ShieldCheck,
  Rocket,
  Coins,
  Globe,
  Users,
  Twitter,
  Send,
  Disc,
  ExternalLink,
  Fish,
  Sparkles,
  BadgeCheck,
  Heart,
} from 'lucide-react'

export default function SOLALandingPage() {
  return (
    <div className="min-h-screen bg-[#03111d] text-white overflow-hidden relative">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-[700px] h-[700px] bg-cyan-400/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-[700px] h-[700px] bg-blue-500/20 rounded-full blur-3xl"></div>
      </div>

      <nav className="sticky top-0 z-50 border-b border-cyan-500/10 backdrop-blur-xl bg-[#03111d]/80">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img
              src="/sola-logo.png"
              alt="SOLA"
              className="w-14 h-14 rounded-full shadow-2xl shadow-cyan-500/40"
            />

            <div>
              <h1 className="text-2xl font-black tracking-wider">SOLA</h1>
              <p className="text-cyan-300 text-sm">the Dolphin</p>
            </div>
          </div>

          <button className="bg-cyan-400 hover:bg-cyan-300 text-black px-6 py-3 rounded-full font-black">
            BUY SOLA
          </button>
        </div>
      </nav>

      <section className="relative z-10 max-w-7xl mx-auto px-6 py-24 grid lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-400/20 px-5 py-2 rounded-full mb-8 text-cyan-200">
            <Sparkles className="w-4 h-4" />
            Solana's Ocean Champion
          </div>

          <h1 className="text-6xl md:text-8xl font-black leading-none mb-8">
            SOLA
            <span className="block text-cyan-300 mt-2 text-5xl md:text-6xl">
              the Dolphin
            </span>
          </h1>

          <p className="text-xl text-slate-300 leading-relaxed max-w-2xl mb-10">
            The cutest and smartest dolphin in crypto is here to dominate the Solana ocean.
            Community powered. Fair launched. Built for real utility and viral energy.
          </p>

          <div className="flex flex-wrap gap-5 mb-12">
            <button className="bg-cyan-400 hover:bg-cyan-300 text-black px-8 py-4 rounded-full font-black text-lg">
              BUY ON PUMP.FUN
            </button>

            <button className="border border-cyan-400/40 px-8 py-4 rounded-full font-bold text-cyan-100">
              READ WHITEPAPER
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="relative flex justify-center"
        >
          <img
            src="/sola-logo.png"
            alt="SOLA"
            className="relative z-10 w-[430px] rounded-full"
          />
        </motion.div>
      </section>

      <section className="relative z-10 bg-white/5 border-y border-cyan-500/10 py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              ['Fair Launch', 'No presale. No insiders.', <Coins className="w-8 h-8" />],
              ['Solana Sonar', 'Future ecosystem safety platform.', <ShieldCheck className="w-8 h-8" />],
              ['Ocean Energy', 'Powered by dolphin vibes.', <Fish className="w-8 h-8" />],
            ].map(([title, text, icon]) => (
              <div
                key={title}
                className="bg-[#071a2c] border border-cyan-400/10 rounded-[30px] p-8"
              >
                <div className="bg-cyan-400/10 text-cyan-300 w-fit p-4 rounded-2xl mb-6">
                  {icon}
                </div>

                <h3 className="text-2xl font-black mb-4">{title}</h3>
                <p className="text-slate-400 leading-relaxed">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="relative z-10 px-6 py-12 border-t border-cyan-500/10 text-center">
        <p className="text-slate-500">
          SOLA the Dolphin • Built on Solana
        </p>
      </footer>
    </div>
  )
}
